import React from 'react';

export function Dashboard() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <p>Protected admin area.</p>
    </div>
  );
}

export default Dashboard;
